


// maximum

console.log(console.log(Math.max(19, 7, 18, 6, 7, 1, 2, 8)));




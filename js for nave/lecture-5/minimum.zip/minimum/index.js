


// minimum



console.log((Math.min(19, 12, 18, 11, 7, 10, 9, 8)));


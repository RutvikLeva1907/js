

// use pop and toString


let arr = [2, 4, 3, 5, 6]

arr.pop()

console.log(arr);
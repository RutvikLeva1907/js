
// lowercase


let arr="RAD AND WHITE"

console.log(arr.toLowerCase());



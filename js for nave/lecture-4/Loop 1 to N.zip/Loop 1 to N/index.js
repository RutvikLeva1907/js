// Loop 1 to N


let num = 5


for (let i = 1; i <= num; i++) {
    console.log(i);

}
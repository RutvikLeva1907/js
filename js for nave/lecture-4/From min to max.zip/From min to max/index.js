// From min to max

let min=14
let max=19


for (let min = 14; min <=max; min++) {
   console.log(min);

}
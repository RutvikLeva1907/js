// Even Sum Below N


let num=6
let sum=0
for (let i = 0; i <=num; i++) {

    if (num%2==0) {
        sum+=i
     
        
    } 
  
}
console.log(sum);
// Divisibly by K


let a = 7
let d = 2

for (let i = 1; i <= a; i++) {
    if (i % d == 0) {
        console.log(i);
    }

}
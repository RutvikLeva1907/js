// Find the largest of two number


let num1 = 5
let num2 = 7

if (num1 > num2) {
    console.log("num1=19");
}
else if (num1 < num2) {
    console.log("num2=7");
}
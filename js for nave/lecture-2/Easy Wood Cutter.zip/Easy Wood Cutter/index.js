// Easy Wood Cutter


let n= 50

if (n%3==0) {
    console.log("yes");   
}
else{
    console.log("no");
}
// Compare two Numbers

  let num1=19
  let num2 =9

  console.log(num1 > num2);
  console.log(num1 < num2);
  console.log(num1 == num2);

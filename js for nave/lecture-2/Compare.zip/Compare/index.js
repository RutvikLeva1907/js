// Compare

let num1=4
let num2 =8

if (num1>num2) {
    console.log("true");    
}else{
    console.log("false");
}

let num3=5

if (num1+num3>num2) {
    console.log("true");

} else {
    console.log("false");

}






// Find odd or even

let d=11

if (d%2==0) {
    console.log("it's an even number");

}
else{
    console.log("it's an odd number");
}


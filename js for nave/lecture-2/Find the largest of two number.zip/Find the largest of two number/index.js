//  Find the largest of thre number


let num1 = 7
let num2 = 3
let num3 = 1

if (num1 > num2) {
    console.log("num1");
}
else if (num1 < num2) {
    console.log("num2");

} else if (num1 < num3) {
    console.log("num3");

}
let distens = 100
let time = 2

speed = distens / time

if (speed > 40) {
    console.log("apley break");
}
else {
    console.log("keep going");
}
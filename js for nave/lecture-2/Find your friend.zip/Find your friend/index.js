

// Find your friend

let n = 15

if (n < 13) {
    console.log("1 Kms");

}
else if (n >= 13 && n < 18) {
    console.log("5 Kms");
}

else if (n >= 18 && n < 30) {
    console.log("10 Kms");

}
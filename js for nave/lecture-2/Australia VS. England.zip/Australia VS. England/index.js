// Australia V/S. England


let Australia = 45
let England = 45

if (Australia > England) {
    console.log("Australia");

} 
else if (Australia < England) {
    console.log("England");
}
else if  (Australia == England) {
    console.log("tie");
}
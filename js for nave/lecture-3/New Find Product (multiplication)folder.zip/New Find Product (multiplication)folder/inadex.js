

// multiplication



let one=3
let tow=2
let three=4
let four=6
let five=5

document.write(one * tow * three * four * five);


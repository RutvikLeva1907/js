

// Square



let d = 7
let Square = d * d

document.write(Square)



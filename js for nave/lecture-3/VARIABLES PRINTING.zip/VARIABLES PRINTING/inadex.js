// Find odd or even with using function



// number = prompt("enter tha number")

// if (number % 2 == 0) {
//     document.write("this number is even")
// } else {
//     document.write("this number is odd")
// }



// multiplication



// let one=3
// let tow=2
// let three=4
// let four=6
// let five=5

// document.write(one * tow * three * four * five);



// Easy Wood Cutter with using function




// let dharmika = 7

// if (dharmika % 3 == 0) {
//     document.write `print ${"Yes"}`;


// } else {
//     document.write `print ${"No"}`;

// }



//  NAME AGE PRINTING with using function

// let name="Dharmika"
// let age="18"

// document.write (name,age)




// Square



// let d = 7
// let Square = d * d

// document.write(Square)



// VARIABLES PRINTING


// let num1=10

// document.write(num1)

//  num1=20
// document.write(num1)



// Multiply by 50



// let num1=2
// let Multiply=num1*50

// document.write(Multiply);




// subtract function



// let one=3
// let tow=2
// let three=4
// let four=6
// let five=5

// document.write(one - tow - three - four - five);




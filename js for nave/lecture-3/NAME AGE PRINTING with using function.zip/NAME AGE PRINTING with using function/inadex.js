


//  NAME AGE PRINTING with using function

let name="Dharmika"
let age="18"

document.write (name,age)



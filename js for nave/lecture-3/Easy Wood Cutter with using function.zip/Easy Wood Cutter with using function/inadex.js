

// Easy Wood Cutter with using function




let dharmika = 7

if (dharmika % 3 == 0) {
    document.write `print ${"Yes"}`;


} else {
    document.write `print ${"No"}`;

}


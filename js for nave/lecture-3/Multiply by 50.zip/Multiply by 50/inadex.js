



// Multiply by 50



let num1=2
let Multiply=num1*50

document.write(Multiply);




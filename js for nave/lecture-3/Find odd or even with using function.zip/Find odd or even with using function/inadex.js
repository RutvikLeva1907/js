// Find odd or even with using function



number = prompt("enter tha number")

if (number % 2 == 0) {
    document.write("this number is even")
} else {
    document.write("this number is odd")
}


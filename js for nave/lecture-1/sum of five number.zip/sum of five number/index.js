


// sum of five number

let one = 7
let tow = 6
let three = 5
let four = 8
let five = 3

console.log(one + tow + three + four + five);




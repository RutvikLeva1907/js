



//  NAME AGE PRINTING


 let name= "Rutvik"
 let age ="18"

 console.log(name ,age);


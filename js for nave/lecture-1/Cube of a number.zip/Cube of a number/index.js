


// Cube of a number


let d = 3
cube = d * d * d
console.log(cube);



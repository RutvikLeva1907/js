


//  VARIABLES PRINTING

let numbar = 10

console.log(numbar);

numbar = 20

console.log(numbar);

// Doubleall 


let one = 10;
let two = 20;
let three = 5;
let four = 8;
let five = 7;

sum= one+ two+ three+ four+five
Double = sum*2

console.log(sum);
console.log(Double);



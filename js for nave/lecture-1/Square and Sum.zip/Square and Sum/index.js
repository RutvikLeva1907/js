



// Square and Sum


let one = 4
let two = 5
let three = 6

let squareOne = one * one;
let squareTwo = two * two;
let squareThree = three * three;




sumofsquare = squareOne + squareTwo + squareThree
console.log(sumofsquare);

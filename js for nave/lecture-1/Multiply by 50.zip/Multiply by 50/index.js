


// Multiply by 50

let a = 3
let b = a * 50

console.log(b);



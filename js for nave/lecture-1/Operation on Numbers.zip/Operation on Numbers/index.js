


//Operation on Numbers

let a=5
let b=3
let c=7
let d=10

console.log((a*b+c)-d);




// Square It


let r = 8
let Square = r * r
console.log(Square);



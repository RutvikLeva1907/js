


// Seven Numbers


let A = 8
let B = 5
let C = 4
let D = 6
let E = 7
let F = 2
let G = 3


console.log((A + B + C) * (D + E + F + G));


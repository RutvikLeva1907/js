


// Find the sum

let a=8
let b=5
let c=4
let d=6

console.log((a+b+c)-d);




// Find the remainder

let one = 10
let tow = 5
let three = 3

result = (one + tow) / three

remainder = (one + tow) % three

console.log(result);
console.log(remainder);


